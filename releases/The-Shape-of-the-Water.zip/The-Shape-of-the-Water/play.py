#!/usr/bin/env python3
"""Run this file with Python 3 to play in your own browser."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser

folder = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(folder))
try:
    server = ThreadingHTTPServer(('127.0.0.1', 4173), handler)
except OSError:
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
url = 'http://127.0.0.1:' + str(server.server_port) + '/'
print('The Shape of the Water: ' + url)
print('Keep this window open while playing. Ctrl+C closes the local server.')
print('Progress is saved in this browser. Export your run before moving browsers or ports.')
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
